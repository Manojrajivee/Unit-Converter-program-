def convert_length(value, from_unit, to_unit):
    units = {
        "m": 1.0,
        "cm": 0.01,
        "km": 1000.0,
        "ft": 0.3048,
        "in": 0.0254,
        "mi": 1609.34
    }
    return value * units[from_unit] / units[to_unit]

def convert_weight(value, from_unit, to_unit):
    units = {
        "kg": 1.0,
        "g": 0.001,
        "lb": 0.453592,
        "oz": 0.0283495
    }
    return value * units[from_unit] / units[to_unit]

def convert_temperature(value, from_unit, to_unit):
    if from_unit == to_unit:
        return value
    if from_unit == "C":
        return value * 9/5 + 32 if to_unit == "F" else value + 273.15
    if from_unit == "F":
        return (value - 32) * 5/9 if to_unit == "C" else (value - 32) * 5/9 + 273.15
    if from_unit == "K":
        return value - 273.15 if to_unit == "C" else (value - 273.15) * 9/5 + 32

def main():
    print("Unit Converter")
    print("1. Length (m, cm, km, ft, in, mi)")
    print("2. Weight (kg, g, lb, oz)")
    print("3. Temperature (C, F, K)")

    choice = input("Choose category (1/2/3): ")

    value = float(input("Enter value: "))
    from_unit = input("From unit: ").lower()
    to_unit = input("To unit: ").lower()

    if choice == "1":
        result = convert_length(value, from_unit, to_unit)
    elif choice == "2":
        result = convert_weight(value, from_unit, to_unit)
    elif choice == "3":
        from_unit = from_unit.upper()
        to_unit = to_unit.upper()
        result = convert_temperature(value, from_unit, to_unit)
    else:
        print("Invalid choice")
        return

    print(f"{value} {from_unit} = {result:.4f} {to_unit}")

if __name__ == "__main__":
    main()